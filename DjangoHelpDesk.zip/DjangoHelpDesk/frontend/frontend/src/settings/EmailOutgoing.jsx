import { BrowserRouter, Route, Routes } from "react-router-dom";

function Email() {
    return (  <>
    <div className="row">

    <div className="col-3">

<div class="list-group">
 <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
    <div class="d-flex w-100 justify-content-between">
      <h5 class="mb-1">Outgoing Email Server</h5>
    </div>

  </a>
 
</div>
    </div>
    

    <div className="col-3">

<div class="list-group">
 <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
    <div class="d-flex w-100 justify-content-between">
      <h5 class="mb-1">Rating Email Template</h5>
    </div>

  </a>
 
</div>
    </div>
    <div className="col-3">

<div class="list-group">
 <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
    <div class="d-flex w-100 justify-content-between">
      <h5 class="mb-1">Sent Ticket Email Template</h5>
    </div>

  </a>
 
</div>
    </div>
    


<br></br>
       








    </div>

    
    </>);
}

export default Email;