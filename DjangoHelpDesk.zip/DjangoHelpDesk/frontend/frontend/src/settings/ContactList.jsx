import axios from "axios";
import { useEffect, useState } from "react";
import ContactKanban from "./Contact";

function ContactList() {
    const [contact,setContact] =useState([])
    useEffect(() => {
        
        axios.get('http://localhost:8000/api/contact').then((response) => {
            setContact(response.data);
        });
      }, []);    return ( <>
    <div className="row">
        {contact?<>
        {contact.map((con)=>(            <ContactKanban contact={con}></ContactKanban>    ))}


        </>:""}


    </div>
    
    </> );
}

export default ContactList;