function ContactKanban(props) {
    return ( <>
    <div className="col-3">
<br></br>
    <div class="list-group">

<a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
  <div class="d-flex w-100 justify-content-between">
    <h5 class="mb-1">{props.contact.name}</h5>
    <small class="text-white bg-info " style={{'padding':"5%"}}>

<div className=""> Ticket</div>
{props.contact.ticket_count}

    </small>


  </div>
  <small class="text-muted">Phone : {props.contact.phone} </small><br></br>
  <small class="text-muted">Email : {props.contact.email}</small>

</a>

</div>
    </div>
   

    </> );
}

export default ContactKanban;