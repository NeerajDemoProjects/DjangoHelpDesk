import { Link } from "react-router-dom";


function Kanban(prop) {
    return (
<div className="col">
    <br></br>
    <Link to={`/view/form?id=${prop.ticket.id}`}>
      <div className="list-group">
  
  <a  className="list-group-item list-group-item-action flex-column align-items-start">
    <div className="d-flex w-100 justify-content-between">
      <h5 className="mb-1">{prop.ticket.number}</h5>
      <small className="text-muted">{prop.ticket.created_at}</small>
    </div>
    <br></br>
    <small className="text-muted"><strong>Name</strong> : {prop.ticket.contact_id.name}</small>
    <br></br>

    <small className="text-muted"><strong>Email</strong>  {prop.ticket.contact_id.email}</small>
    <br></br>

    <small className="text-muted"><strong>Phone</strong> {prop.ticket.contact_id.phone}</small>
<br></br>
<hr></hr>
    <h6>Query</h6>
    <hr></hr>
     {prop.ticket.query}
  </a>
</div>
</Link>

<br></br>
</div>

      );
}

export default Kanban;