import axios from "axios";
import { useEffect, useState } from "react";
import Sidebar from "../sidebar/sidebar";
import Kanban from "./Kanban";
import Stage from "./stage";

function Main() {
    const [ticket ,setTicket] = useState([])
    const [kanbanrecord,setKanbanRecord]=useState()
    const baseURL = 'http://localhost:8000/api/get/ticket'
    useEffect(() => {
        axios.get(baseURL).then((response) => {
            setTicket(response.data);
            var KanbanRecord = {'new':[],'in_progress':[],'closed':[],'rated':[]}

            for (var i = 0; i < response.data.length; i++) {
                KanbanRecord[response.data[i]["state_id"]].push(response.data[i])


                }
                setKanbanRecord(KanbanRecord)

            });
      }, []);
      console.log(kanbanrecord)
    return (<>
    <br></br>
    <div className="row">
  
           <div className="col">

           {kanbanrecord?<div>
           
           <div className="row">
           <div className="col">            <Stage name="New" count={kanbanrecord['new'].length}></Stage>

{kanbanrecord['new'].map((ticket)=>(<Kanban ticket={ticket}></Kanban>
))}
           
</div>
          
          
<div className="col">            <Stage name="In Progress" count={kanbanrecord['in_progress'].length}></Stage>

{kanbanrecord['in_progress'].map((ticket)=>(<Kanban ticket={ticket}></Kanban>
))}
           
</div>
<div className="col">            <Stage name="Closed" count={kanbanrecord['closed'].length}></Stage>

{kanbanrecord['closed'].map((ticket)=>(<Kanban ticket={ticket}></Kanban>
))}
           
</div>
<div className="col">            <Stage name="Rating" count={kanbanrecord['rated'].length}></Stage>

{kanbanrecord['rated'].map((ticket)=>(<Kanban ticket={ticket}></Kanban>
))}
           
</div>
          
          
          
          
          
</div>

          
          
          
          
          
          </div>:""}




           </div>
          


    </div>
        

    


           


        
           

            {/* {ticket.map((ticket)=>(

<Kanban ticket={ticket}></Kanban>



            ))}
       */}


    </>
        
        
       );
}

export default Main;