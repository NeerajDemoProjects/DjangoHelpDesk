import SentimentSatisfiedAltIcon from '@mui/icons-material/SentimentSatisfiedAlt';
import SentimentVeryDissatisfiedIcon from '@mui/icons-material/SentimentVeryDissatisfied';
import axios from 'axios';
import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
function CustomerRating() {
const location =useLocation()
const [rates,setRate] =useState('btn btn-light')
const [id,setID] = useState('')
const URL ='http://localhost:8000/api/get/rating/ticket?'+location['search']
const [is_not_expired,setIsnotExpired]= useState([false])

console.log(location)
const baseURL = 'http://localhost:8000/api/get/rating/ticket?'+location['search']
    useEffect(() => {
        axios.get(baseURL).then((response) => {
            setIsnotExpired(response.data);
        });
        axios.get( 'http://localhost:8000/api/get/rating/status/ticket'+location['search']).then((response) => {
            setRate(response.data['rating'])
            setID(response.data['id'])
        });


        
      }, []);

      console.log(is_not_expired)
const handlesatisfy = ()=>{
    axios.post(URL,{"id":id,"rating":"satisfied"})
    window.location.reload()
}

const handleunsatisfy = ()=>{

    axios.post(URL,{"id":id,"rating":"unsatisfied"})
    window.location.reload()


}

return (<>


{is_not_expired? <div className="container">

    <div class="card">
  <div className="card-body" style={{'text-align':"left","padding":"1%"}}>
  <p>Dear valued customer,</p>
    <p>We value your feedback and always strive to provide you with the best possible service. We understand that sometimes you may encounter issues while using our helpdesk, and we want to ensure that we address any concerns you may have.</p>
    <p>To assist us in improving our services, we kindly request that you take a moment to rate your experience with our helpdesk. Your honest feedback is extremely valuable to us and will help us to identify areas for improvement and enhance the overall customer experience.</p>  </div>

<div className="row">
    <div className="col">
    <button type="button" className={(rates==='satisfied')?'btn btn-danger':'btn btn-light'} onClick={()=>handlesatisfy()}> <SentimentSatisfiedAltIcon  style={{"fontSize":"100px"}}></SentimentSatisfiedAltIcon></button>

        
       </div>
    <div className="col">
    <button type="button" className={(rates==='unsatisfied')?'btn btn-danger':'btn btn-light'} onClick={()=>handleunsatisfy()}>
        <SentimentVeryDissatisfiedIcon   style={{"fontSize":"100px"}}></SentimentVeryDissatisfiedIcon>
        </button>
        </div>
</div>
</div>
    </div>:<div>
        The Link Expired
        </div>}










   













    </>

        
    
        
   
);
}

export default CustomerRating;