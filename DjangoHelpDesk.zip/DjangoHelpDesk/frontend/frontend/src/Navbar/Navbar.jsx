import { Link } from "@mui/icons-material";
import PeopleIcon from '@mui/icons-material/People';
import LocalActivityIcon from '@mui/icons-material/LocalActivity';
import MailIcon from '@mui/icons-material/Mail';
import LogoutIcon from '@mui/icons-material/Logout';
import { Button } from "bootstrap";
import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
function Navbar() {

  const [user,setUser]=useState()

  
  useEffect(() => {
    axios.defaults.headers.common['Authorization']="JWT " +localStorage.getItem('accessToken')

    axios.get('http://localhost:8000/auth/users/me/').then((response) => {
      setUser(response.data['username']);
    });
  }, []);

  const handlelogout = ()=>{

    localStorage.removeItem('accessToken') 
    window.location.reload()
  }
  console.log(user)

    return ( 
        <>


<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">HelpDesk</a>

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <ul class="navbar-nav mr-auto" style={{'margin-right':"0%"}}>
      {user?  <li class="nav-item active">
      <button type="button" class="btn btn-primary" onClick={()=>handlelogout()}>Logout</button>

        </li>: <li class="nav-item active">
        <a  class="nav-link" href="/login">Login </a>

        </li>}
       
      
   </ul>




<a href="/login">Login</a>

  </nav>






  
        </>
     );
}

export default Navbar;