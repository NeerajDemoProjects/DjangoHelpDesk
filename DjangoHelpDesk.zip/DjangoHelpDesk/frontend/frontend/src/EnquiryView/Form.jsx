import axios from "axios";
import { useEffect, useState } from "react";
import Chatter from "../Enquiry/Chatter";
import ChatterView from "./ChatterView";
import PersonIcon from '@mui/icons-material/Person';
import { useLocation } from "react-router-dom";
function EnquiryFormView() {

    const location = useLocation()
    console.log(location)
    const [ticket,setTicket]=useState([])
    const  baseURL ='http://localhost:8000/api/get/client/ticket'+location['search']

    useEffect(() => {
        axios.get(baseURL).then((response) => {
            setTicket(response.data);
        });
      }, []);
    const handleClose =(id)=>{axios.put('http://127.0.0.1:8000/api/get/close/ticket',{'id':id})
      window.location.reload()
}

    return (<>
    {ticket.map((ticket)=>(


<div className="container">
<div class="list-group">

<a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
<div class="d-flex w-100 justify-content-between">
<h5 class="mb-1">{ticket.number}</h5>
<small class="text-muted">{ticket.created_at}</small>
<button type="button" class="btn btn-info" onClick={()=>{handleClose(ticket.id)}}>Close Ticket</button>

</div>
<p class="mb-1">{ticket.contact_id.name}</p>
<small class="text-muted">Phone : {ticket.contact_id.phone}</small><br></br>
<small class="text-muted">Email : {ticket.contact_id.email}</small><br></br>

<small class="text-muted">Query : {ticket.contact_id.query}</small><br></br>

</a>

<br></br>


<ChatterView ticket={ticket}></ChatterView>








</div>
<Chatter ticket={ticket}></Chatter>



</div>


    ))}
   
    <br></br>
    </>  );
}

export default EnquiryFormView;