import PersonIcon from '@mui/icons-material/Person';

function ChatterView(props) {
  console.log(props)
    return (  <>
    <div class="list-group">
{props.ticket.message_ids.map((message)=>(

<div class="alert alert-secondary" role="alert">

<div class="alert " style={{'textAlign':'left'}} role="alert">
<h6><PersonIcon></PersonIcon>{message.name}</h6>
<small>{message.created_at}</small>
<hr></hr>
<p>{message.message}</p>
</div>
</div>

))}
  
 
</div>
    </>);
}

export default ChatterView;