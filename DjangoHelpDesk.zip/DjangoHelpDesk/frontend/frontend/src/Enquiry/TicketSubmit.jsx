import axios from "axios";
import { useState } from "react";

function TicketSubmit() {
    const url ='http://localhost:8000/api/create/ticket'
    const [name ,setName]=useState('')
    const [email ,setEmail]=useState('')
    const [phone ,setPhone]=useState('')
    const [query ,setQuery]=useState('')

    const  handleSubmit = ()=>{
        axios.defaults.headers.common['Authorization']="JWT " +localStorage.getItem('accessToken')

            var record ={
                "name": name,
                "phone":  phone,
                "email": email,
                "query": query
            }
             axios.post(url,record,
             {
                headers: {
                    'Authorization': "JWT " +localStorage.getItem('accessToken') }})


            // fetch(url, {
            //     method: 'POST',
            //     headers: {
            //       'Content-Type': 'application/json'
            //     },
            //     body: record
            //   })


    }

    return ( <div className="container">
      
<br></br>

<div class="list-group">
 
  <a  class="list-group-item list-group-item-action flex-column ">
    <h1>Customer Enquiry</h1>
  <br></br>
  <br></br>

  <div >

    
  <div class="form-group">
    <div className="row">
    <div className="col-1">Name</div>
    <div className="col"><input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Name"
    
    onChange={(e)=>setName(e.target.value)}
    required/>
</div>
</div>
<br></br>

<div className="row">
    <div className="col-1">Email</div>
    <div className="col"><input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Email"
    
    onChange={(e)=>setEmail(e.target.value)}

    
    required/>
</div>
</div>
<br></br>
<div className="row">
    <div className="col-1">Phone</div>
    <div className="col"><input type="text"     onChange={(e)=>setPhone(e.target.value)}
 class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Phone" required/>
</div>
</div>
<br></br>

<div className="row">
    <div className="col-1">Query</div>
    <div className="col"><textarea 
        onChange={(e)=>setQuery(e.target.value)}

    class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Query" required/>
</div>
</div>



   <br></br>
 
   <button  class="btn btn-primary"  onClick={(e)=>handleSubmit()}>Submit</button>

  </div>
  
</div>
  </a>
</div>







    
    </div> );
}

export default TicketSubmit;