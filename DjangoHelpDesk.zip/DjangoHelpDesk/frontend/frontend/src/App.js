import logo from './logo.svg';
import './App.css';
import Main from './Kanban/Main';
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap/dist/js/bootstrap.js'
import MainEnquiry from './Enquiry/MainEnquiry';
import EnquiryFormView from './EnquiryView/Form';
import CustomerRating from './Rating/RatingForm';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from './Navbar/Navbar';
import Sidebar from './sidebar/sidebar';
import SubNavbar from './Navbar/subnavbar';
import ContactList from './settings/ContactList';
import Email from './settings/EmailOutgoing';
import { Login } from '@mui/icons-material';
import LoginPage from './Login/Login';
import { useEffect, useState } from 'react';
import axios from 'axios';




function App() {

const [user,setUser]= useState(false)

  useEffect(() => {
    axios.defaults.headers.common['Authorization']="JWT " +localStorage.getItem('accessToken')

    axios.get('http://localhost:8000/api/user').then((response) => {
      setUser(response.data)
    
    });
  }, []);

  


  return (
    <div className="App">
<Navbar></Navbar>


{user?<div>


  <SubNavbar></SubNavbar>
  



  <BrowserRouter>
        <Routes>  
  
        <Route path="/" element={<Main></Main>} />
        
        <Route path="/login" element={<LoginPage></LoginPage>    } />
        <Route path="/ticket" element={<Main></Main>} />
        
        <Route path="/contact" element={<ContactList></ContactList>} />
  
        <Route path="/view/form/*" element={<div>
          <br></br>
        <EnquiryFormView></EnquiryFormView>
        </div>
        }>
  </Route>
  <Route path="/view/rating/*" element={<div>
          <br></br>
        <CustomerRating></CustomerRating>
        </div>
        }>
  </Route>
  
  <Route path="/view/enquiry/*" element={<div>
          <br></br>
        <MainEnquiry></MainEnquiry>
        </div>
        }>
  </Route>
  
  
  <Route path="/email/*" element={<div>
          <br></br>
        <Email></Email>
        </div>
        }>
  </Route>
  
  
        </Routes>
        </BrowserRouter>
  
</div>:<div>
  
  
<BrowserRouter>
        <Routes> 
        <Route path="/" element={<div>
          <br></br>
        <MainEnquiry></MainEnquiry>
        </div>
        }>
  </Route>


      

        <Route path="/login" element={<LoginPage></LoginPage>    } />
        <Route path="/view/form/*" element={<div>
          <br></br>
        <EnquiryFormView></EnquiryFormView>
        </div>
        }>
  </Route>


  <Route path="/view/rating/*" element={<div>
          <br></br>
        <CustomerRating></CustomerRating>
        </div>
        }>
  </Route>

        </Routes>
</BrowserRouter>
  
  </div>}



    </div>
  );
}

export default App;
