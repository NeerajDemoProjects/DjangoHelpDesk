import { Padding } from "@mui/icons-material";
import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";


function LoginPage() {
const [email,setUsername]=useState()
const [pass,setPass]=useState()
axios.defaults.headers.common['Authorization']="JWT " +localStorage.getItem('accessToken')
const usenavigate=useNavigate();
const handleLogin=()=>{



    axios.post('http://localhost:8000/auth/jwt/create',{
        "username":email,
        "password": pass
    }).then(response=>(
        localStorage.setItem('accessToken',response.data.access),
        usenavigate('/'),
        window.location.reload()
        
    
    ))
}


    return ( 

<div style={{"width":"25%","margin-left":"35%","margin-top":"10%","margin-right":"25%",'justifyContent':"center"}}



>
  <div class="form-outline mb-4">
  <label class="form-label" for="form2Example1" >Username:</label>

    <input type="text" id="form2Example1" onChange={(e)=>setUsername(e.target.value)}  class="form-control" />
  </div>

  <div class="form-outline mb-4">
  <label class="form-label" for="form2Example2">Password</label>

    <input type="password" id="form2Example2" onChange={(e)=>setPass(e.target.value)}  class="form-control" />
  </div>

  <div class="row mb-4">
    <div class="col d-flex justify-content-center">
   
    </div>

    <div class="col">
    </div>
  </div>

  <button onClick={()=>{handleLogin()}} class="btn btn-primary btn-block mb-4">Sign in</button>

 
</div>
        
     );
}

export default LoginPage;