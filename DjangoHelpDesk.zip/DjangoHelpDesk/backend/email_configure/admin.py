from django.contrib import admin
from .models import OutgoingEmailServer,CustomRatingEmailTemplate,CustomTicketEmailTemplate
admin.site.register(OutgoingEmailServer)
admin.site.register(CustomRatingEmailTemplate)
admin.site.register(CustomTicketEmailTemplate)

# Register your models here.
