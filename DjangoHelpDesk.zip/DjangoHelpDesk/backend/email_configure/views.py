# from django.shortcuts import render
from rest_framework.generics import ListAPIView

# Create your views here.
