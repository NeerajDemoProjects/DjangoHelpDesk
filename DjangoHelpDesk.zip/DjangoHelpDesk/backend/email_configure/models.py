from django.db import models
from django import forms
import django.db.models.deletion

class Message(models.Model):
    name = models.CharField(max_length=30)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)


class CustomRatingEmailTemplate(models.Model):
    subject = models.CharField(max_length=50)
    body = models.TextField()
class CustomTicketEmailTemplate(models.Model):
    subject = models.CharField(max_length=50)
    body = models.TextField()

class OutgoingEmailServer(models.Model):
    email_address = models.EmailField()
    email_password = models.CharField(max_length=100)
    smtp_server = models.CharField(max_length=100)
    port = models.IntegerField()
    ticket= models.ForeignKey(CustomTicketEmailTemplate, on_delete=models.CASCADE)
    custom_rating= models.ForeignKey(CustomRatingEmailTemplate, on_delete=models.CASCADE)









