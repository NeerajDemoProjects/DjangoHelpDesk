# from django.shortcuts import render
from rest_framework.generics import ListAPIView
from rest_framework.views import APIView
from .models import Ticket
from contact.models import Contact
from .serializer import TicketSerializer,TicketCreateSerializer
from rest_framework.response import Response
from email_configure.models import OutgoingEmailServer
import smtplib
from email.message import EmailMessage
from django.db import IntegrityError
import datetime
import pytz
from django.db import connection

from jinja2 import Environment, Template
env = Environment()



def creation_email_ticket(EMAIL_TO,ticket):
    email_configure = OutgoingEmailServer.objects.all().first()
    EMAIL_ADDRESS = email_configure.email_address
    EMAIL_PASS =  email_configure.email_password
    msg = EmailMessage()
    print()
    msg['Subject'] = email_configure.ticket.subject +" | "+str(ticket.number)
    msg['From'] = EMAIL_ADDRESS
    msg['To'] =EMAIL_TO
    jinja_msg = email_configure.ticket.body
    template = env.from_string(jinja_msg)
    context = {
        'ticket':{ 'name':ticket.contact_id.name,'email':ticket.contact_id.email,'phone':ticket.contact_id.phone,'number':ticket.number,

                   'url':'http://localhost:3000/view/form?id='+str(ticket.id)}}

    html_msg = template.render(context)
    msg.add_alternative(html_msg, subtype="html")

    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login(EMAIL_ADDRESS, EMAIL_PASS)
        smtp.send_message(msg)



def creation_email_rating(EMAIL_TO,ticket):
    print("called")
    email_configure = OutgoingEmailServer.objects.all().first()
    EMAIL_ADDRESS = email_configure.email_address
    EMAIL_PASS =  email_configure.email_password
    msg = EmailMessage()
    msg['Subject'] = email_configure.custom_rating.subject+"|"+str(ticket.number)
    msg['From'] = EMAIL_ADDRESS
    msg['To'] =EMAIL_TO
    jinja_msg = email_configure.custom_rating.body
    template = env.from_string(jinja_msg)
    context = {
        'ticket':{ 'name':ticket.contact_id.name,'email':ticket.contact_id.email,'phone':ticket.contact_id.phone,'number':ticket.number,

                   'url':'http://localhost:3000/view/rating?id='+str(ticket.id)}}

    html_msg = template.render(context)
    msg.add_alternative(html_msg, subtype="html")

    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login(EMAIL_ADDRESS, EMAIL_PASS)
        smtp.send_message(msg)

def creation_email_message(EMAIL_TO,ticket,message):
    email_configure = OutgoingEmailServer.objects.all().first()
    EMAIL_ADDRESS = email_configure.email_address
    EMAIL_PASS =  email_configure.email_password
    msg = EmailMessage()
    msg['Subject'] = str(ticket.number)
    msg['From'] = EMAIL_ADDRESS
    msg['To'] =EMAIL_TO
    jinja_msg = "<p><strong>{{message.name}}</strong>" \
                "<p>{{message.message}}</p><hr></hr>"
    template = env.from_string(jinja_msg)
    context = {'message':{'name':message.name,'message':message.message}}

    html_msg = template.render(context)
    msg.add_alternative(html_msg, subtype="html")

    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login(EMAIL_ADDRESS, EMAIL_PASS)
        smtp.send_message(msg)


class GetUserCreateTicket(APIView):
    def get(self, request):
          print("user",request.user.id,request.user.username)
          if request.user.username:
             return Response(True)
          else:
              return Response(False)

class CreateTicket(APIView):
    authentication_classes = []
    def post(self, request):
        serializer = TicketCreateSerializer(data=request.data)


        if serializer.is_valid():
            try :
                contact,var =Contact.objects.get_or_create(name=serializer.data['name'],email=serializer.data['email'],
                                                           phone =serializer.data['phone']

                                                           )
                ticket = Ticket.objects.create(contact_id=contact,query=serializer.data['query'],state_id="new")

                creation_email_ticket(contact.email,ticket)
                # message = ticket.message_ids.create(name=request.user.username if request.user.id else ticket.contact_id.name,message = "created")
                # ticket.message_ids.add(message)
                ticket.save()
                return Response(serializer.data, status=400)

            except IntegrityError as e:
                contacts = Contact.objects.get(email=serializer.data['email'])
                ticket = Ticket.objects.create(contact_id=contacts,query=serializer.data['query'],state_id="new")
                message = ticket.message_ids.create(
                    name=request.user.username if request.user.id else ticket.contact_id.name, message="created")
                ticket.message_ids.add(message)
                ticket.save()
                creation_email_ticket(contacts.email,ticket)
                return Response(serializer.data, status=400)


            return Response(serializer.data, status=400)


        return Response("Invalid request")
    def put(self, request):

         id =request.data['id']
         message = request.data['message']
         ticket = Ticket.objects.get(id=id)
         if ticket.closed:
             return Response("Ticket is closed", status=400)

         else:
             message_id = ticket.message_ids.create(
                 name=request.user.username if request.user.id else ticket.contact_id.name,
                 message=message)

             ticket.message_ids.add(message_id)
             ticket.state_id ="in_progress"
             ticket.save()
             creation_email_message(ticket.contact_id.email,ticket,message_id)
             return Response("Created Successfull", status=400)

    def get(self, request):
          print("user",request.user.id,request.user.username)
          if request.user.username:
             return Response(True)
          else:
              return Response(False)


class TicketList(ListAPIView):
    serializer_class=TicketSerializer
    queryset = Ticket.objects.all()

    def get(self, request):
        queryset = self.get_queryset()
        serializer = TicketSerializer(queryset, many=True)
        return Response(serializer.data)

class TicketClientList(ListAPIView):
    authentication_classes = []
    serializer_class=TicketSerializer
    queryset = Ticket.objects.all()

    def get(self, request):
        queryset = self.get_queryset()
        queryset=queryset.filter(id=request.GET.get('id'))
        serializer = TicketSerializer(queryset, many=True)
        return Response(serializer.data)
class CloseTicket(APIView):
    authentication_classes = []
    def put(self, request):

        id = request.data['id']
        ticket = Ticket.objects.get(id=id)
        ticket.created_rating = datetime.datetime.now()
        if  not ticket.closed:
            message_id = ticket.message_ids.create(
                name=request.user.username if request.user.id else ticket.contact_id.name,
                message=str(request.user.username if request.user.id  else ticket.contact_id.name)+" has Closed the Ticket -"+str(ticket.number))
            ticket.message_ids.add(message_id)
            ticket.closed = True
            ticket.state_id="closed"
            ticket.save()
            creation_email_message(ticket.contact_id.email, ticket, message_id)
            creation_email_rating(ticket.contact_id.email,ticket)
        return Response("Created Successfull", status=400)

class RatingTicket(APIView):
    authentication_classes = []
    def post(self, request):
        id =request.data['id']
        print("<<>>>>",id)
        rating = request.data['rating']

        ticket = Ticket.objects.get(id=id)
        if ticket.is_expired:
            return Response("The Link Expired", status=400)
        else:
            message_id = ticket.message_ids.create(
                    name=request.user.username if request.user.id else ticket.contact_id.name,
                    message="Rated the Ticket as "+rating)
            ticket.message_ids.add(message_id)
            # ticket.is_expired = True
            ticket.custom_rate = rating
            ticket.state_id="rated"

            ticket.save()
            return Response("Created Successfull", status=400)

    def get(self, request):
        id = request.GET.get('id')
        print(">>>>>>>>>>",id)
        ticket = Ticket.objects.get(id=id)
        max = ticket.created_rating+datetime.timedelta(minutes=30)


        ticket.last_visited = datetime.datetime.now()
        ticket.save()
        ticket = Ticket.objects.get(id=id)

        if max>ticket.last_visited:
            ticket.is_expired = False
        else:
            ticket.is_expired = True
        return Response(not ticket.is_expired)
class GetRatingTicket(APIView):
    authentication_classes = []
    def get(self, request):
        id = request.GET.get('id')
        print(id)
        ticket = Ticket.objects.get(id=id)
        print(ticket)
        return Response({'rating':ticket.custom_rate,'id':ticket.id})



class ContactTicket(APIView):
    def get(self, request):
        print("users",request.user)
        with connection.cursor() as cursor:
            cursor.execute('''
            SELECT COUNT(ticket_ticket.contact_id_id) as ticket_count, 
            contact_contact.name ,
            contact_contact.email
            ,contact_contact.phone
            FROM ticket_ticket,
            contact_contact 
            where contact_contact.id 
            = ticket_ticket.contact_id_id
            GROUP BY ticket_ticket.contact_id_id, 
            contact_contact.name,
            contact_contact.email,contact_contact.phone;''')
            data = cursor.fetchall()
            print(data)
            data = [dict(zip([column[0] for column in cursor.description], row)) for row in data]
            print(data)
            return Response(data)



